import { getPageUser, getUserTotal } from '@/api/user'
export default {
  namespaced: true,
  state: {
    list: [],
    page: 1, // 当前的页码
    size: 10, // 每页获取的数据
    total: 0 // 管理员总数量
  },
  mutations: {
    SET_LIST (state, list) {
      state.list = list
    },
    SET_TOTAL (state, total) {
      state.total = total
    },
    SET_PAGE (state, page) {
      state.page = page
    }
  },
  actions: {
    getUserList ({ commit, state }) {
      getPageUser(state.page, state.size).then(res => {
        commit('SET_LIST', res)
      })
    },
    getUserTotal ({ commit }) {
      getUserTotal().then(res => {
        commit('SET_TOTAL', res[0].total || 0)
      })
    }
  }
}