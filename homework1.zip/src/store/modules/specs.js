// 导入会员的接口文件（分页获取）
import { getPageSpecs, getSpecsTotal } from '@/api/specs'
export default {
  namespaced: true,
  state: {
    list: [],
    page: 1, // 当前的页码
    size: 10, // 每页获取的数据
    total: 0 // 管理员总数量
  },
  mutations: {
    SET_LIST (state, list) {
      state.list = list
    },
    SET_TOTAL (state, total) {
      state.total = total
    },
    SET_PAGE (state, page) {
      state.page = page
    }
  },
  actions: {
    getSpecsList ({ commit, state }) {
      getPageSpecs(state.page, state.size).then(res => {
        console.log(res)
        commit('SET_LIST', res)
      })
    },
    getSpecsTotal ({ commit }) {
      getSpecsTotal().then(res => {
        commit('SET_TOTAL', res[0].total || 0)
      })
    }
  }
}
