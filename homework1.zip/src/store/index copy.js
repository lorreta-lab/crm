import Vue from 'vue'
// 引入vuex
import Vuex from 'vuex'

// 使用vuex插件
Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    num: 0,
    user: {
      name: '张三',
      age: 20
    },
    surname: ['赵', '钱', '孙', '李', '周', '吴', '郑', '王'], // 姓氏
    name: ['三', '四', '站', '德华', '学友', '杰伦'] // 名
  },
  // 相当于vue组件的计算属性
  getters: {
    roleName (state) {
      const sK = Math.floor(Math.random() * state.surname.length)
      const nK = Math.floor(Math.random() * state.name.length)
      return state.surname[sK] + state.name[nK]
    }
  },
  mutations: {
    // mutations的函数  名称(state, payLoad), 建议使用全部大写
    SET_NUM (state, payLoad) {
      console.log(payLoad)
      // 修改state对应的数据
      // 不能使用异步函数
      state.num = payLoad.value + payLoad.step
    },
    SET_USER (state, user) {
      state.user = user
    }
  },
  actions: {
    // 可以使用异步函数
    // 一个actions函数可以调用多个mutations
    // 名称(store, payLoad)
    setUser ({ commit }, user) {
      commit('SET_USER', user)
    }
  }
})

export default store
