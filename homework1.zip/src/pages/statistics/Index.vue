<template>
<div>
  <!--
    栅格布局
    gutter: 栅格间隔
  -->
  <el-row :gutter="20">
    <!--
      列的设置
      span: 栅格占据的列数（没有响应式）
    -->
    <el-col :span="12">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>图表1</span>
        </div>
        <div ref="chart1" style="width:100%;height:300px;"></div>
      </el-card>
    </el-col>
    <el-col :span="12">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>图表2</span>
        </div>
        <div ref="chart2" style="width:100%;height:300px;"></div>
      </el-card>
    </el-col>
  </el-row>
</div>
</template>

<script>
import * as echarts from 'echarts'

export default {
  mounted () {
    this.$nextTick(() => {
      this.echartInit1()
      this.echartInit2()
    })
  },
  methods: {
    echartInit1 () {
      // 初始化 echarts.init(DOM)
      const chartObj = echarts.init(this.$refs.chart1)
      // 定义图表的选项
      const option = {
        xAxis: {
          // x坐标的设置
          type: 'category',
          // x坐标的描述, 元素的个数需要和series中data的个数一致
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        },
        yAxis: {
          // y坐标的设置
          type: 'value'
        },
        series: [{
          // data 要展示的数据
          data: [150, 230, 224, 218, 135, 147, 360],
          type: 'bar'
        }]
      }
      // 设置图片的选项
      chartObj.setOption(option)
    },
    echartInit2 () {
      // 初始化 echarts.init(DOM)
      const chartObj = echarts.init(this.$refs.chart2)
      // 定义图表的选项
      const option = {
        xAxis: {
          // x坐标的设置
          type: 'category',
          // x坐标的描述, 元素的个数需要和series中data的个数一致
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        },
        yAxis: {
          // y坐标的设置
          type: 'value'
        },
        series: [{
          // data 要展示的数据
          data: [150, 230, 224, 218, 135, 147, 360],
          type: 'line'
        }]
      }
      // 设置图表的选项
      chartObj.setOption(option)
    }
  }
}
</script>
<style scoped>

</style>