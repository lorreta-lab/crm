<template>
<div>
  <h1 class="title">stylus less sass</h1>
  <div class="nav">
    <div class="logo">
      <a href="">Logo</a>
    </div>
    <ul>导航</ul>
  </div>
  <div class="footer">
    底部
  </div>
</div>
</template>

<script>
export default {

}
</script>
<style lang="stylus" scoped>
/*
  style里面的语法就是stylus
  所有的css的语法都可以直接使用
  .title
    font-size 20px
  =>
  .title{
    font-size: 20px;
  }

  层级关系：
  .nav
    width 100%
    height 60px
    background #f90
    .logo
      width 200px
      height 100%
      background #ccc
  =>
  .nav .logo {
    width: 200px;
    height: 100%;
    background: #ccc;
  }

  使用&代替父级
  a
    &:hover
      color #000
  =>
  a:hover{
    color: #000;
  }

  变量:
  bgcolor = #c00 // 导航条的背景颜色
  $logo-bgcolor = pink // logo区域的背景颜色

  函数(可以有返回值)/mixin(混入) 就是一段css的代码，没有返回值
  不能使用css的属性当做函数的名称

*/
// 定义变量
bgcolor = #c00 // 导航条的背景颜色
$logo-bgcolor = pink // logo区域的背景颜色

// 定义一个mixin
demo()
  width 100%
  height 60px
  background bgcolor

// 定义一个函数
w(n)
  return 2 * n // return 可以省略

.title
  font-size 20px
.nav
  demo()
  font-size 20px
  .logo
    width w(200px)
    height 100%
    background $logo-bgcolor
    a
      color #fff
      &:hover
        color #000

.footer
  demo()
  margin-top 20px
</style>
