<template>
<div class="container">
  <div class="login-form">
    <h3 class="title">管理员登录</h3>
    <el-form ref="form" :rules="rules" :model="loginData">
      <el-form-item label="" prop="username">
        <el-input v-model="loginData.username" placeholder="请输入账号" clearable>
          <template slot="prepend">
             <i class="el-icon-s-custom"></i>
          </template>
        </el-input>
      </el-form-item>
      <el-form-item label="" prop="password">
        <el-input v-model="loginData.password" show-password placeholder="请输入密码" clearable>
          <template slot="prepend">
             <i class="el-icon-lock"></i>
          </template>
        </el-input>
      </el-form-item>
      <el-form-item label="">
         <el-button type="primary" style="width: 100%;" @click="onSubmit">登录</el-button>
      </el-form-item>
    </el-form>
  </div>
</div>
</template>

<script>
// 从user中导入登录的方法
import { login } from '@/api/user'
export default {
  data () {
    return {
      loginData: {
        username: '',
        password: ''
      },
      // 表单验证规则
      rules: {
        // 规则的编写 属性(要验证的属性): 规则
        username: [
          // 规则
          { required: true, message: '请输入账号', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    onSubmit () {
      // 触发表单验证 调用Form组件的validate(回调函数)方法(是异步方法)
      this.$refs.form.validate(valid => {
        // valid 表示验证是否全部通过
        if (valid) {
          // 全部通过， 做登录处理
          this.login()
        }
      })
    },
    login () {
      // 登录处理
      login(this.loginData.username, this.loginData.password).then(res => {
        // 登录成功, 把返回的信息保存到sessionStorage
        sessionStorage.setItem('user', JSON.stringify(res))
        // 跳转到后台首页
        this.$router.push('/')
      }).catch(err => {
        // 登录失败， 显示错误信息
        this.$message.error(err.message)
      })
    }
  }
}
</script>
<style scoped>
.container{
  width: 100%;
  height: 100%;
  background: url('~@/assets/images/bg.jpg') no-repeat;
  background-size: cover;
  display: flex;
  justify-content: center;
  align-items: center;
}
.login-form{
  background: #fff;
  padding: 15px 25px;
  border-radius: 10px;
}
.login-form .title{
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 20px;
  width: 100%;
  text-align: center;
}
</style>
