<template>
<el-container style="height: 100%;overflow: hidden;">
  <el-header style="padding: 0;">
    <u-header/>
  </el-header>
  <el-container>
    <el-aside width="200px" style="background-color: #545C64;">
      <u-menu/>
    </el-aside>
    <el-main class="main-container">
      <!--面包屑-->
      <el-breadcrumb separator="/" style="margin-bottom: 10px;">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <!--当前路由的meta的标题-->
        <el-breadcrumb-item>{{$route.meta.title || ''}}</el-breadcrumb-item>
      </el-breadcrumb>
      <!--嵌套路由-->
      <router-view />
    </el-main>
  </el-container>
</el-container>
</template>

<script>
import UHeader from './components/Header'
import UMenu from './components/Menu'
export default {
  components: {
    UHeader,
    UMenu
  }
}
</script>
<style scoped>
.main-container{
  width: 100%;
  height: calc(100% - 60px);
  overflow: auto;
}
</style>
