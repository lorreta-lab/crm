<template>
<!--
  导航菜单组件
  el-menu 容器组件
  @open 监听下拉菜单打开
  @close 监听下拉菜单关闭

  default-active: string  默认选中的菜单项的index的值
  background-color 菜单的背景色
  text-color 文本的颜色
  active-text-color  菜单被选中时的文本颜色
  router
    是否使用 vue-router 的模式，启用该模式会在激活导航时以 index 作为 path 进行路由跳转
    default-active设置为当前路由的path
-->
<!--
  el-dialog: 弹出对话框组件
  title: 对话框的标题
  visible: 是否显示
-->
<el-menu
  router
  :default-active="$route.path"
  background-color="#545c64"
  text-color="#fff"
  active-text-color="#ffd04b">
  <!--没有下级菜单的菜单项-->
  <el-menu-item index="/statistics">
    <i class="el-icon-s-home"></i>
    <span slot="title">首页</span>
  </el-menu-item>
  <template v-for="(menu,index) of menuList">
    <!--有下级菜单-->
    <el-submenu :index="'1' + index" :key="menu.id"  v-if="menu.children && menu.children.length > 0">
      <!--一级菜单的名称-->
      <template slot="title">
        <i v-if="menu.icon !== ''" :class="menu.icon"></i>
        <span>{{menu.title}}</span>
      </template>
      <!--二级菜单项-->
      <el-menu-item-group>
        <el-menu-item v-for="item of menu.children" :key="item.id" :index="item.url">
          <i v-if="item.icon !== ''" :class="item.icon"></i>
          <span slot="title">{{item.title}}</span>
        </el-menu-item>
      </el-menu-item-group>
    </el-submenu>
    <el-menu-item :index="menu.url" v-else :key="menu.id">
      <i class="el-icon-s-home"></i>
      <span slot="title">首页</span>
    </el-menu-item>
  </template>
</el-menu>
</template>

<script>
export default {
  data () {
    return {
      menuList: []
    }
  },
  mounted () {
    const userInfo = JSON.parse(sessionStorage.getItem('user'))
    this.menuList = userInfo.menus || []
    console.log(userInfo)
  }
}
</script>
<style scoped>
.el-menu{
  border-right: none;
}
</style>
