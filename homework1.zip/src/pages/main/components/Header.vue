<template>
<div class="header-container">
  <div class="logo">
    小U商城后台管理系统
  </div>
  <!--
    下拉菜单容器
    @command 监听指令事件 需要在el-dropdown-item添加command属性
  -->
  <el-dropdown @command="handleCommand">
    <span class="el-dropdown-link">
      欢迎！{{username}}<i class="el-icon-arrow-down el-icon--right"></i>
    </span>
    <!--
      下拉菜单
    -->
    <el-dropdown-menu slot="dropdown">
      <!--
        下拉菜单选项
        divided 添加横线
        disabled 禁用
      -->
      <el-dropdown-item command="updateInfo">个人信息</el-dropdown-item>
      <el-dropdown-item command="updatePassword">修改密码</el-dropdown-item>
      <el-dropdown-item divided command="onLogout">退出系统</el-dropdown-item>
    </el-dropdown-menu>
  </el-dropdown>
</div>
</template>

<script>
export default {
  data () {
    return {
      username: ''
    }
  },
  mounted () {
    // 从本地存储获取登录用户的信息
    const userInfo = JSON.parse(sessionStorage.getItem('user'))
    this.username = userInfo.username // 获取登录用户的账号
  },
  methods: {
    handleCommand (command) {
      // 必须保证command和对应的方法的名称相同
      this[command]()
    },
    onLogout () {
      // 退出系统
      // 清除本地存储中的登录用户信息
      sessionStorage.removeItem('user')
      // 跳转到登录页面
      this.$router.replace('/login')
    },
    updatePassword () {
      console.log('updatePassword')
    },
    updateInfo () {
      console.log('updateInfo')
    }
  }
}
</script>
<style scoped>
.header-container{
  width: 100%;
  height: 100%;
  background: #518ECB;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0  20px;
  box-sizing: border-box;
}
.logo{
  font-size: 20px;
  font-weight: 700;
  color: #fff;
}
.el-dropdown-link{
  color: #fff;
}
</style>
