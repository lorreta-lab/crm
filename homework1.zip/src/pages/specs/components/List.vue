<template>
<div>
  <!--
  普通数据表格
  data:  要显示的数据
  row-key:  循环的tr的key值 对应的菜单数据中的编号
  border 是否添加表格的边框
  default-expand-all 是否展开所有的数据
  tree-props:  下级数据的结构 {children(表格组件的属性): 'children(菜单数据对应的下级菜单)'}
-->
<el-table
  :data="list"
  style="width: 100%;margin: 20px 0;"
  row-key="id"
  border
>
  <!--
    el-table-column 表格的列组件
    prop:  菜单数据中对应的数据
    label:  表头
  -->
  <el-table-column
    prop="specsname"
    label="名称"
  >
  </el-table-column>
  <el-table-column
    prop="attrs"
    label="属性"
  >
  <template #default="props">
    <el-tag v-for="item of props.row.attrs" type="info" :key="item" style="margin-right:5px;">{{item}}</el-tag>
  </template>
  </el-table-column>
  <el-table-column
    label="状态">
  <template #default="props">
    <el-tag v-if="props.row.status === 1">正常</el-tag>
    <el-tag v-else type="danger">禁用</el-tag>
  </template>
  </el-table-column>
  <el-table-column
    label="操作">
  <template #default="props">
    <el-button type="primary" size="mini" @click="onEdit(props.row)"><i class="el-icon-edit"></i> 编辑</el-button>
    <!--ID等于1的管理员不允许删除-->
    <el-button type="danger" size="mini" @click="onDelete(props.row)" v-if="props.row.id > 1"><i class="el-icon-delete"></i> 删除</el-button>
  </template>
  </el-table-column>
</el-table>
<!--
  分页组件
  layout 组件布局，子组件名用逗号分隔 sizes, prev, pager, next, jumper, ->, total, slot
  total: 总数量
  page-size: 每页的数量
  @current-change 当前页码发生改变时触发

  至少有2页时才显示分页组件
-->
<el-pagination
  @current-change="onCurrentChange"
  class="page-container"
  :page-size="size"
  background
  layout="prev, pager, next"
  :total="total"
  v-if="total > size"
>
</el-pagination>
</div>
</template>

<script>
import { deleteSpecs } from '@/api/specs'
import { mapState } from 'vuex'
export default {
  computed: {
    ...mapState({
      list: state => state.specs.list, // 当前页的管理员列表数据
      size: state => state.specs.size, // 每页显示的数量
      page: state => state.specs.page, // 当前页
      total: state => state.specs.total // 管理员总数量
    })
  },
  mounted () {
    // 通过vuex分页获取管理员数据
    this.$store.dispatch('specs/getSpecsList')
    // 通过vuex获取管理员总数量
    this.$store.dispatch('specs/getSpecsTotal')
  },
  methods: {
    onCurrentChange (page) {
      // 更改vuex中的当前页
      this.$store.commit('specs/SET_PAGE', page)
      // 重新获取当前页的管理员数据
      this.$store.dispatch('specs/getSpecsList')
    },
    onEdit (data) {
      // 触发编辑按钮
      // 通知父组件显示编辑菜单的对话框，把当前要编辑的数据传递出去
      this.$emit('edit', data)
    },
    onDelete (data) {
      // element-ui的弹出框 this.$confirm(显示的信息[, 标题, 其他的配置项目])
      // 是一个Promise函数
      this.$confirm('确定要删除吗？', '提示', { type: 'error' }).then(() => {
        // 做删除功能
        // 调用接口删除角色
        deleteSpecs(data.id).then(() => {
          this.$message.success({
            message: '删除成功',
            onClose: () => {
              // 重新获取总数量
              this.$store.dispatch('specs/getSpecsTotal')
              // 如果当前页的数据已经全部删除，就修改page
              // 刷新列表数据之前，要删除的数据还没有变化
              if (this.list.length === 1) {
                let page = 0
                if (this.page === 1) {
                  page = 1
                } else {
                  page = this.page - 1
                }
                this.$store.commit('specs/SET_PAGE', page)
              }
              // 刷新列表数据
              this.$store.dispatch('specs/getSpecsList')
            }
          })
        }).catch(err => {
          this.$message.error(err.message)
        })
      }).catch(() => {})
    }
  }
}
</script>
<style scoped>
.page-container{
  display: flex;
  justify-content: flex-end;
}
</style>
