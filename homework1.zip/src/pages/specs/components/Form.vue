<template>
<!--
  el-dialog: 弹出对话框组件
  title: 对话框的标题
  visible: 是否显示
-->
<el-dialog :title="title" :visible.sync="dialogFormVisible" @close="clearForm">
  <el-form :model="form" ref="form" :rules="rules" label-width="120px" label-suffix="：">
    <el-form-item label="规格名称" prop="specsname">
      <el-input v-model.trim="form.specsname" placeholder="请输入规格名称"></el-input>
    </el-form-item>
    <el-form-item label="规格属性" v-for="(item, index) of attrList" :key="index">
      <div class="item-container">
        <el-input v-model.trim="item.value" placeholder="请输入规格名称"></el-input>
        <el-button type="primary" v-if="index === 0" @click="addAttr">新增</el-button>
        <el-button type="danger" v-else @click="removeAttr(index)">删除</el-button>
      </div>
    </el-form-item>
    <el-form-item label="状态">
      <!--
        开关组件
        active-value: Boolean | string | number   选中时的值
        inactive-value: Boolean | string | number   未选中时的值
      -->
      <el-switch
        v-model="form.status"
        :active-value="1"
        :inactive-value="2"
      >
      </el-switch>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="onSubmit">提 交</el-button>
    </el-form-item>
  </el-form>
</el-dialog>
</template>

<script>
import { mapState } from 'vuex'
// 引入接口方法
// 导出所有的非default的内容
import * as model from '@/api/specs'

const defaultData = {
  specsname: '', // 规格名称(必填)
  attrs: '', // 规格属性
  status: 1 // 状态 1正常2禁用
}
export default {
  data () {
    return {
      dialogFormVisible: false,
      title: '', // 对话框的标题
      form: {...defaultData}, // 复制一份默认数据
      rules: {
        specsname: [
          { required: true, message: '请输入规格名称', trigger: 'blur' }
        ]
      },
      attrList: [{ value: '' }] // 属性数组
    }
  },
  computed: {
    ...mapState({
      // 获取角色信息
      roleList: state => state.role.list
    })
  },
  mounted () {
    // 如果没有角色信息，重新获取角色信息
    if (this.roleList.length === 0) {
      this.$store.dispatch('role/getRoleList')
    }
  },
  methods: {
    addAttr () {
      this.attrList.push({ value: '' })
    },
    removeAttr (index) {
      this.attrList.splice(index, 1)
    },
    onSubmit () {
      this.$refs.form.validate(valid => {
        if (valid) {
          // 根据form数据中是否有id属性来判断当前是修改菜单还是添加菜单
          if (this.form.id && this.form.id > 0) {
            // 修改
            this.eidtSpecs('updateSpecs')
          } else {
            // 添加
            this.eidtSpecs()
          }
        }
      })
    },
    eidtSpecs (method = 'addSpecs') {
      // 从规格属性中过滤出不为空的数据，然后要转换为字符串
      this.form.attrs = this.attrList.filter(item => item.value !== '').map(item => item.value).join(',')
      if (this.form.attrs === '') {
        this.$message.error('请输入规格属性')
        return
      }
      model[method](this.form).then(() => {
        // 修改成功
        // 显示添加成功的信息
        this.$message.success({
          message: method === 'addSpecs' ? '添加成功' : '修改成功',
          onClose: () => {
            // 关闭对话框(一旦对话框关闭就会自动触发对话框的close事件)
            this.dialogFormVisible = false
            if (method === 'addSpecs') {
              // 添加时重新获取总数量
              this.$store.dispatch('specs/getSpecsTotal')
            }
            // 刷新列表数据
            this.$store.dispatch('specs/getSpecsList')
          }
        })
      }).catch(err => {
        this.$message.error(err.message)
      })
    },
    clearForm () {
      // 把表单数据还原到原始值
      this.form = {...defaultData}
      // 清空规格属性
      this.attrList = [{ value: '' }]
      // 清空所有的表单验证
      this.$nextTick(() => {
        this.$refs.form.clearValidate()
      })
    },
    // 修改时设置表单的数据
    setFormData (data) {
      // 修改时把密码清空
      // 处理规格属性
      if (data.attrs !== '') {
        this.attrList = data.attrs.map(item => ({ value: item }))
      }
      this.form = {...data}
    }
  }
}
</script>
<style scoped>
.item-container{
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: space-between;
}
</style>
