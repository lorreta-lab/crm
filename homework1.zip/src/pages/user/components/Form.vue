<template>
<!--
  el-dialog: 弹出对话框组件
  title: 对话框的标题
  visible: 是否显示
-->
<el-dialog :title="title" :visible.sync="dialogFormVisible" @close="clearForm">
  <el-form :model="form" ref="form" :rules="rules" label-width="120px" label-suffix="：">
    <el-form-item label="选择角色" prop="roleid">
      <el-select v-model="form.roleid" placeholder="请选择">
        <!-- 当value和v-model的值相等的时候就选中 value和v-model是全等比较-->
        <!--循环角色信息-->
        <el-option label="请选择角色" :value="0"></el-option>
        <el-option v-for="item of roleList" :key="item.id" :label="item.rolename" :value="item.id"></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="账号" prop="username">
      <el-input v-model.trim="form.username" placeholder="请输入账号"></el-input>
    </el-form-item>
    <el-form-item label="密码" prop="password">
      <el-input show-password v-model="form.password" :placeholder="form.id > 0 ? '不填代表不修改密码' : '请输入密码'"></el-input>
    </el-form-item>
    <el-form-item label="状态">
      <!--
        开关组件
        active-value: Boolean | string | number   选中时的值
        inactive-value: Boolean | string | number   未选中时的值
      -->
      <el-switch
        v-model="form.status"
        :active-value="1"
        :inactive-value="2"
      >
      </el-switch>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="onSubmit">提 交</el-button>
    </el-form-item>
  </el-form>
</el-dialog>
</template>

<script>
import { mapState } from 'vuex'
// 引入接口方法
// 导出所有的非default的内容
import * as model from '@/api/user'

const defaultData = {
  roleid: 0, // 角色ID
  username: '', // 管理员账号(必填)
  password: '', // 管理员的密码(添加时必填，修改时可以不填(不填代表不修改密码))
  status: 1 // 状态 1正常2禁用
}
export default {
  data () {
    // 自定义验证规则
    // value就是要验证的表单项的值
    // callback: function 输出验证的信息
    //   验证通过调用callback() 验证没有通过调用callback(Error对象)
    const checkRole = (rule, value, callback) => {
      // 如果值不为0代表通过
      // 是菜单的时候链接就必填
      if (value === 0) {
        callback(new Error('请选择角色'))
      } else {
        callback()
      }
    }
    const checkPassword = (rule, value, callback) => {
      // 添加时必填，修改时可以不填
      if (this.form.id > 0) {
        callback()
      } else {
        if (value === '') {
          callback(new Error('请输入密码'))
        } else {
          callback()
        }
      }
    }
    return {
      dialogFormVisible: false,
      title: '', // 对话框的标题
      form: {...defaultData}, // 复制一份默认数据
      rules: {
        // 0也代表已填
        // 如果没有使用自定义验证，那规则的属性就必须在表单的数据中存在
        roleid: [
          { validator: checkRole, trigger: 'change' }
        ],
        username: [
          { required: true, message: '请输入账号', trigger: 'blur' }
        ],
        password: [
          { validator: checkPassword, trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    ...mapState({
      // 获取角色信息
      roleList: state => state.role.list
    })
  },
  mounted () {
    // 如果没有角色信息，重新获取角色信息
    if (this.roleList.length === 0) {
      this.$store.dispatch('role/getRoleList')
    }
  },
  methods: {
    onSubmit () {
      this.$refs.form.validate(valid => {
        if (valid) {
          // 根据form数据中是否有id属性来判断当前是修改菜单还是添加菜单
          if (this.form.id && this.form.id > 0) {
            // 修改
            this.eidtUser('updateUser')
          } else {
            // 添加
            this.eidtUser()
          }
        }
      })
    },
    eidtUser (method = 'addUser') {
      model[method](this.form).then(() => {
        // 修改成功
        // 显示添加成功的信息
        this.$message.success({
          message: method === 'addUser' ? '添加成功' : '修改成功',
          onClose: () => {
            // 关闭对话框(一旦对话框关闭就会自动触发对话框的close事件)
            this.dialogFormVisible = false
            if (method === 'addUser') {
              // 添加时重新获取总数量
              this.$store.dispatch('user/getUserTotal')
            }
            // 刷新列表数据
            this.$store.dispatch('user/getUserList')
          }
        })
      }).catch(err => {
        this.$message.error(err.message)
      })
    },
    clearForm () {
      // 把表单数据还原到原始值
      this.form = {...defaultData}
      // 清空所有的表单验证
      this.$nextTick(() => {
        this.$refs.form.clearValidate()
      })
    },
    // 修改时设置表单的数据
    setFormData (data) {
      // 修改时把密码清空
      const editData = {...data} // 复制一份传入的管理员数据
      editData.password = ''
      this.form = editData
    }
  }
}
</script>
<style scoped>

</style>
