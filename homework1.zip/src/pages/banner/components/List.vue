<template>
  <div>
      <el-table
  :data="list"
  style="width: 100%;margin: 20px 0;"
  row-key="id"
  border
>
  <!--
    el-table-column 表格的列组件
    prop:  菜单数据中对应的数据
    label:  表头
  -->
  <el-table-column
    label="编号"
    width="100"
  >
  <template slot-scope="scope">
      {{scope.$index+1}}
  </template>
  </el-table-column>
  <el-table-column
    prop="title"
    label="轮播图标题"
    width="300"
  >
  </el-table-column>
  <el-table-column
    label="图片"
    width="300"
  >
  <template #default="props">
    <img v-if="props.row.img !== ''" :src="props.row.img | recombinationImg" height="80" />
  </template>
  </el-table-column>
  <el-table-column
    label="状态"
    width="300"
  >
  <template #default="props">
    <el-tag v-if="props.row.status === 1">启用</el-tag>
    <el-tag v-else type="danger">禁用</el-tag>
  </template>
  </el-table-column>
  <el-table-column
    label="操作"
  >
  <template #default="props">
    <el-button type="primary" size="mini" @click="onEdit(props.row)">编辑<i class="el-icon-edit"></i></el-button>
    <el-button type="danger" size="mini" @click="onDelete(props.row)">删除<i class="el-icon-delete"></i></el-button>
  </template>
  </el-table-column>
</el-table>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { deleteBanner } from '@/api/banner'
export default {
computed: {
    ...mapState({
      list: state => state.banner.list
    })
  },
  mounted () {
    // 从后端获取菜单数据
    // 判断是否获取过菜单数据，如果没有就重新获取
    if (this.list.length === 0) {
      this.$store.dispatch('banner/getBannerList')
    }
  },
    methods: {
    onEdit (data) {
      // 触发编辑按钮
      // 通知父组件显示编辑菜单的对话框，把当前要编辑的数据传递出去
      this.$emit('edit', data)
    },
    onDelete (data) {
      // element-ui的弹出框 this.$confirm(显示的信息[, 标题, 其他的配置项目])
      // 是一个Promise函数
      this.$confirm('确定要删除吗？', '提示', { type: 'error' }).then(() => {
        // 做删除功能
        // 调用接口删除角色
        deleteBanner(data.id).then(() => {
          this.$message.success({
            message: '删除成功',
            onClose: () => {
              // 刷新列表数据
              this.$store.dispatch('banner/getBannerList')
            }
          })
        }).catch(err => {
          this.$message.error(err.message)
        })
      }).catch(() => {})
    }
  }
}
</script>

<style>

</style>