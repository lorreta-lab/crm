<template>
  <div class="activity-form">
      <el-dialog :title="title" :visible.sync="dialogFormVisible" @close="clearForm" width="80%" top="5vh">
    <el-form ref="form" :model="form">
      <el-form-item label="活动名称">
        <!--
			input组件
			clearable: 是否添加清除内容的图标
		-->
        <el-input v-model="form.title" placeholder="" clearable>
        </el-input>
      </el-form-item>
      <el-form-item label="活动期限">
        <el-date-picker
          v-model="value1"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :picker-options="pickerOptions"
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item label="一级分类">
        <el-select
          v-model="form.first_cateid"
          placeholder="请选择"
          @change="onChangeCategory"
        >
          <!-- 当value和v-model的值相等的时候就选中 value和v-model是全等比较-->
          <el-option label="请选择一级分类" :value="0"></el-option>
          <!--循环一级分类-->
          <el-option
            v-for="item of firstCategoryList"
            :key="item.id"
            :label="item.catename"
            :value="item.id"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="二级分类">
        <el-select v-model="form.second_cateid" placeholder="请选择">
          <!-- 当value和v-model的值相等的时候就选中 value和v-model是全等比较-->
          <el-option label="请选择二级分类" :value="0"></el-option>
          <!--循环一级分类-->
          <el-option
            v-for="item of secondCategoryList"
            :key="item.id"
            :label="item.catename"
            :value="item.id"
          ></el-option>
        </el-select>
      </el-form-item>
     <el-form-item label="商品">
        <el-select v-model="form.goodsid" placeholder="请选择">
          <!-- 当value和v-model的值相等的时候就选中 value和v-model是全等比较-->
          <el-option label="请选择商品" :value="0"></el-option>
          <!--循环一级分类-->
          <el-option v-for="item of goodsList" :key="item.id" :label="item.goodsname" :value="item.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="状态">
        <!--
        开关组件
        active-value: Boolean | string | number   选中时的值
        inactive-value: Boolean | string | number   未选中时的值
      -->
        <el-switch v-model="form.status" :active-value="1" :inactive-value="2">
        </el-switch>
      </el-form-item>
      <el-form-item label="">
        <el-button type="primary" style="width: 100%" @click="onSubmit"
          >添加</el-button
        >
      </el-form-item>
    </el-form>
    </el-dialog>
  </div>
</template>

<script>
import { mapState,mapGetters } from "vuex";
import goodsRules from '@/validate/goods'
import { validate } from '@/utils/function'
// 引入接口方法
// 导出所有的非default的内容
import * as model from "@/api/seckill";
const defaultData = {
  title: "", // 1级分类ID(必填)
  first_cateid: 0, // 商品价格(必填)
  second_cateid: 0, // 市场价格(必填)
  goodsid: 0, // 是否热卖推荐 1-是 2-否
  status: 1, // 状态 1正常2禁用
};
export default {
  data() {
    return {
      pickerOptions: {
        shortcuts: [
          {
            text: "最近一周",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近一个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近三个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit("pick", [start, end]);
            },
          },
        ],
      },
      value1: "",
      dialogFormVisible:false,
      title: "添加秒杀",
      activeName: 'base',  // 对话框的标题
      form: { ...defaultData }, // 复制一份默认数据
      secondCategoryList: [], // 二级分类数据
      goodsList1: [], // 规格的属性数据
    };
  },
  computed: {
    ...mapState({
      categoryList: state => state.category.list, // 获取分类列表
      goodsList: state => state.goods.list // 获取所有的规格
    }),
    ...mapGetters({
      // 获取一级分类
      firstCategoryList: 'category/firstCategoryList'
    })
  },
   mounted () {
    // 如果没有分类数据，重新获取分类数据
    if (this.categoryList.length === 0) {
      this.$store.dispatch('category/getCategoryList')
    this.$store.dispatch('goods/getGoodsList')}
  },
  methods:{
       onChangeCategory (id) {
      // 清空表单的second_cateid
      this.form.second_cateid = 0
      if (id > 0) {
        // 如果id>0则获取当前分类的二级分类
        const category = this.categoryList.find(item => item.id === id) // 根据id在分类数据中查找对应的分类
        this.secondCategoryList = category.children || []
      } else {
        // 如果id为0则清空二级分类
        this.secondCategoryList = []
      }
    },
    onSubmit () {
      this.$refs.form.validate(valid => {
        if (valid) {
          // 处理数据
          // 根据form数据中是否有id属性来判断当前是修改还是添加
          if (this.form.id && this.form.id > 0) {
            // 修改
            this.eidtRole('updateSeckill')
          } else {
            // 添加
            this.eidtRole()
          }
        }
      })
    },
    eidtRole (method = 'addSeckill') {
      model[method](this.form).then(() => {
        // 修改成功
        // 显示添加成功的信息
        this.$message.success({
          message: method === 'addSeckill' ? '添加成功' : '修改成功',
          onClose: () => {
            // 关闭对话框(一旦对话框关闭就会自动触发对话框的close事件)
            this.dialogFormVisible = false
            // 刷新列表数据
            this.$store.dispatch('seckill/getSeckillList')
          }
        })
      }).catch(err => {
        this.$message.error(err.message)
      })
    },
    clearForm () {
      // 关闭对话框
      // 还原表单数据
      this.form = {...defaultData}
      // 清除表单验证
      this.$refs.form.clearValidate()
    },
    setFormData (data) {
      // 根据商品的1级分类设置2级分类的数据
      /*const category = this.categoryList.find(item => item.id === data.first_cateid)
      this.secondCategoryList = category.children || []
      // 保存商品的图片
      this.editDefaultImg = data.img*/
      this.form={...data}
    }
  }
};
</script>

<style scoped>
.activity-form {
  background: #fff;
}
</style>
