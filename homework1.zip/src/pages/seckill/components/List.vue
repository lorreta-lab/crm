<template>
  <div>
  <!--
  普通数据表格
  data:  要显示的数据
  row-key:  循环的tr的key值 对应的菜单数据中的编号
  border 是否添加表格的边框
  default-expand-all 是否展开所有的数据
  tree-props:  下级数据的结构 {children(表格组件的属性): 'children(菜单数据对应的下级菜单)'}
-->
<el-table
  :data="list"
  style="width: 100%;margin: 20px 0;"
  row-key="id"
  border
>
  <!--
    el-table-column 表格的列组件
    prop:  菜单数据中对应的数据
    label:  表头
  -->
  <el-table-column
    prop="title"
    label="名称"
  >
  </el-table-column>
  <el-table-column
    label="状态">
  <template #default="props">
    <el-tag v-if="props.row.status === 1">正常</el-tag>
    <el-tag v-else type="danger">禁用</el-tag>
  </template>
  </el-table-column>
  <el-table-column
    label="操作">
  <template #default="props">
    <el-button type="primary" size="mini" @click="onEdit(props.row)"><i class="el-icon-edit"></i> 编辑</el-button>
    <!--ID等于1的管理员不允许删除-->
    <el-button type="danger" size="mini" @click="onDelete(props.row)" v-if="props.row.id > 1"><i class="el-icon-delete"></i> 删除</el-button>
  </template>
  </el-table-column>
</el-table>
<!--
  分页组件
  layout 组件布局，子组件名用逗号分隔 sizes, prev, pager, next, jumper, ->, total, slot
  total: 总数量
  page-size: 每页的数量
  @current-change 当前页码发生改变时触发

  至少有2页时才显示分页组件
-->
</div>
</template>

<script>
import { mapState } from 'vuex'
import { deleteSeckill } from '@/api/seckill'
export default {
computed: {
    ...mapState({
      list: state => state.seckill.list
    })
  },
  mounted () {
    // 从后端获取菜单数据
    // 判断是否获取过菜单数据，如果没有就重新获取
    if (this.list.length === 0) {
      this.$store.dispatch('seckill/getSeckillList')
    }
  },
    methods: {
    onEdit (data) {
      // 触发编辑按钮
      // 通知父组件显示编辑菜单的对话框，把当前要编辑的数据传递出去
      this.$emit('edit', data)
    },
    onDelete (data) {
      // element-ui的弹出框 this.$confirm(显示的信息[, 标题, 其他的配置项目])
      // 是一个Promise函数
      this.$confirm('确定要删除吗？', '提示', { type: 'error' }).then(() => {
        // 做删除功能
        // 调用接口删除角色
        deleteSeckill(data.id).then(() => {
          this.$message.success({
            message: '删除成功',
            onClose: () => {
              // 刷新列表数据
              this.$store.dispatch('seckill/getSeckillList')
            }
          })
        }).catch(err => {
          this.$message.error(err.message)
        })
      }).catch(() => {})
    }
  }
}
</script>

<style>

</style>