<template>
<el-dialog :title="title" :visible.sync="dialogFormVisible" @close="clearForm">
  <el-form :model="form" ref="form" :rules="rules" label-width="120px" label-suffix="：">
    <el-form-item label="角色名称" prop="rolename">
      <el-input v-model.trim="form.rolename" placeholder="请输入角色名称"></el-input>
    </el-form-item>
    <el-form-item label="选择权限" prop="menus">
      <!--
        显示菜单数据
        树形控件
        data 要显示的数据
        show-checkbox  是否显示checkbox框数据
        node-key: node的key 对应的菜单数据的编号
        props 节点配置 {children(下级节点): '菜单数据中对应的下级名称', label(节点显示的名称): '菜单数据中的标题'}
        default-expand-all 是否展开所有的节点
        check-strictly: 是否联动选择(选择父节点的时候是否选中所有的子节点)
      -->
      <el-tree
        ref="tree"
        :data="menuList"
        node-key="id"
        show-checkbox
        default-expand-all
        :props="{children: 'children', label: 'title'}"
        :check-strictly="checkStrictly"
      >
      </el-tree>
    </el-form-item>
    <el-form-item label="状态">
      <!--
        开关组件
        active-value: Boolean | string | number   选中时的值
        inactive-value: Boolean | string | number   未选中时的值
      -->
      <el-switch
        v-model="form.status"
        :active-value="1"
        :inactive-value="2"
      >
      </el-switch>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="onSubmit">提 交</el-button>
    </el-form-item>
  </el-form>
</el-dialog>
</template>

<script>
import { mapState } from 'vuex'
// 导出角色管理的接口文件
import * as model from '@/api/role'
// 默认数据
const defaultData = {
  rolename: '', // 角色名称
  menus: '', // 角色选择的菜单
  status: 1 // 状态 1正常2禁用
}
export default {
  data () {
    const checkMenus = (rule, value, callback) => {
      // 获取树形控件的选择的节点
      // this.$refs.tree.getCheckedKeys() 获取选中的节点的key
      // this.$refs.tree.getHalfCheckedKeys() 获取半选中的节点的key
      const selectMenus = [...this.$refs.tree.getCheckedKeys(), ...this.$refs.tree.getHalfCheckedKeys()]
      if (selectMenus.length === 0) {
        this.form.menus = '' // 还原表单数据中的菜单
        // 没有选择任何的菜单
        callback(new Error('请选择权限'))
      } else {
        this.form.menus = selectMenus // 把选择的权限赋值给表单数据
        callback()
      }
    }
    return {
      title: '', // 对话框的标题
      dialogFormVisible: false, // 是否显示对话框
      form: {...defaultData}, // 复制一份默认数据
      rules: {
        rolename: [
          { required: true, message: '请输入角色名称', trigger: 'blur' }
        ],
        menus: [
          { validator: checkMenus, trigger: 'change' }
        ]
      },
      checkStrictly: false
    }
  },
  computed: {
    ...mapState({
      menuList: state => state.menu.list
    })
  },
  mounted () {
    // 判断是否获取过菜单数据，如果没有就重新获取
    if (this.menuList.length === 0) {
      this.$store.dispatch('menu/getMenuList')
    }
  },
  methods: {
    clearForm () {
      // 关闭对话框
      // 还原表单数据
      this.form = {...defaultData}
      // 清除表单验证
      this.$refs.form.clearValidate()
    },
    onSubmit () {
      this.$refs.form.validate(valid => {
        if (valid) {
          // 处理数据
          // 根据form数据中是否有id属性来判断当前是修改还是添加
          if (this.form.id && this.form.id > 0) {
            // 修改
            this.eidtRole('updateRole')
          } else {
            // 添加
            this.eidtRole()
          }
        }
      })
    },
    eidtRole (method = 'addRole') {
      model[method](this.form).then(() => {
        // 修改成功
        // 显示添加成功的信息
        this.$message.success({
          message: method === 'addRole' ? '添加成功' : '修改成功',
          onClose: () => {
            // 关闭对话框(一旦对话框关闭就会自动触发对话框的close事件)
            this.dialogFormVisible = false
            // 刷新列表数据
            this.$store.dispatch('role/getRoleList')
          }
        })
      }).catch(err => {
        this.$message.error(err.message)
      })
    },
    // 修改的时候设置表单数据
    setFormData (data) {
      this.form = {...data}
      // 给树形控件赋值
      // data.menus '1,2,3'
      const keys = data.menus.split(',')
      this.checkStrictly = true // 在渲染树形组件之前关闭父子节点的联动选择
      this.$nextTick(() => {
        // 将回调延迟到下次 DOM 更新循环之后执行。在本次dom完全渲染之后触发
        this.$refs.tree.setCheckedKeys(keys) // 参数必须是数组
        this.checkStrictly = false // 在赋值之后开启父子节点的联动选择
      })
    }
  }
}
</script>
<style scoped>

</style>
