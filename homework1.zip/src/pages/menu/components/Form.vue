<template>
<!--
  el-dialog: 弹出对话框组件
  title: 对话框的标题
  visible: 是否显示
-->
<el-dialog :title="title" :visible.sync="dialogFormVisible" @close="clearForm">
  <el-form :model="form" ref="form" :rules="rules" label-width="120px" label-suffix="：">
    <el-form-item :label="form.type === 1 ? '目录名称' : '菜单名称'" prop="title">
      <el-input v-model.trim="form.title" placeholder="请输入名称"></el-input>
    </el-form-item>
    <el-form-item label="上级菜单">
      <el-select v-model="form.pid" placeholder="请选择">
        <!-- 当value和v-model的值相等的时候就选中 value和v-model是全等比较-->
        <el-option label="顶级菜单" :value="0"></el-option>
        <!--循环一级菜单-->
        <el-option v-for="item of firstMenuList" :key="item.id" :label="'|- ' + item.title" :value="item.id"></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="类型">
      <!--单选框组-->
      <el-radio-group v-model="form.type">
        <el-radio :label="1">目录</el-radio>
        <el-radio :label="2">菜单</el-radio>
      </el-radio-group>
    </el-form-item>
    <el-form-item :label="form.type === 1 ? '目录图标' : '菜单图标'">
      <el-input v-model="form.icon" placeholder="请输入图标的样式名称"></el-input>
    </el-form-item>
    <el-form-item v-show="form.type === 2" label="菜单链接" prop="url">
      <el-input v-model.trim="form.url" placeholder="请输入菜单链接"></el-input>
    </el-form-item>
    <el-form-item label="状态">
      <!--
        开关组件
        active-value: Boolean | string | number   选中时的值
        inactive-value: Boolean | string | number   未选中时的值
      -->
      <el-switch
        v-model="form.status"
        :active-value="1"
        :inactive-value="2"
      >
      </el-switch>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="onSubmit">提 交</el-button>
    </el-form-item>
  </el-form>
</el-dialog>
</template>

<script>
import { mapGetters } from 'vuex'
// 引入接口方法
// 导出所有的非default的内容
import * as model from '@/api/menu'

const defaultData = {
  pid: 0, // 上级菜单的编号 顶级菜单就是0
  title: '', // 菜单的名称(必填)
  icon: '', // 菜单的图标
  type: 1, // 菜单的类型 1目录2菜单
  url: '', // 菜单的链接(如果是菜单才必填)
  status: 1 // 状态 1正常2禁用
}
export default {
  data () {
    // 自定义验证规则
    // value就是要验证的表单项的值
    // callback: function 输出验证的信息
    //   验证通过调用callback() 验证没有通过调用callback(Error对象)
    const checkUrl = (rule, value, callback) => {
      // 如果是菜单的时候链接就必填
      if (this.form.type === 1) {
        callback() // 验证通过
      } else {
        // 是菜单的时候链接就必填
        if (value === '') {
          callback(new Error('请输入菜单链接'))
        } else {
          callback()
        }
      }
    }
    return {
      dialogFormVisible: false,
      title: '', // 对话框的标题
      form: {...defaultData}, // 复制一份默认数据
      rules: {
        title: [
          { required: true, message: '请输入名称', trigger: 'blur' }
        ],
        url: [
          { validator: checkUrl, trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    ...mapGetters({
      firstMenuList: 'menu/firstMenuList'
    })
  },
  methods: {
    onSubmit () {
      this.$refs.form.validate(valid => {
        if (valid) {
          // 根据form数据中是否有id属性来判断当前是修改菜单还是添加菜单
          if (this.form.id && this.form.id > 0) {
            // 修改
            this.eidtMenu('updateMenu')
          } else {
            // 添加
            this.eidtMenu()
          }
        }
      })
    },
    eidtMenu (method = 'addMenu') {
      model[method](this.form).then(() => {
        // 修改成功
        // 显示添加成功的信息
        this.$message.success({
          message: method === 'addMenu' ? '添加成功' : '修改成功',
          onClose: () => {
            // 关闭对话框(一旦对话框关闭就会自动触发对话框的close事件)
            this.dialogFormVisible = false
            // 刷新列表数据
            this.$store.dispatch('menu/getMenuList')
          }
        })
      }).catch(err => {
        this.$message.error(err.message)
      })
    },
    clearForm () {
      // 把表单数据还原到原始值
      this.form = {...defaultData}
      // 清空所有的表单验证
      this.$refs.form.clearValidate()
    }
  }
}
</script>
<style scoped>

</style>
