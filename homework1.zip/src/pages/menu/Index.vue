<template>
<div>
<el-button type="primary" plain size="small" @click="showAddMenu">添加菜单</el-button>
<u-form ref="form"/>
<u-list @edit="showEditMenu"/>
</div>
</template>

<script>
import UList from './components/List'
import UForm from './components/Form'
export default {
  components: {
    UList,
    UForm
  },
  methods: {
    showAddMenu () {
      // 显示菜单对话框
      this.$refs.form.dialogFormVisible = true
      // 修改对话框的标题
      this.$refs.form.title = '添加菜单'
    },
    showEditMenu (data) {
      console.log(data)
      // 显示菜单对话框， 添加和修改使用的是同一个组件
      this.$refs.form.dialogFormVisible = true
      // 修改对话框的标题
      this.$refs.form.title = '修改菜单'
      // 把要编辑的菜单的数据复制给对话框
      this.$refs.form.form = {...data}
    }
  }
}
</script>
<style scoped>
</style>
