import Vue from 'vue'
import Router from 'vue-router'
// 导入路由规则
import routes from './routes'

Vue.use(Router)

const router = new Router({
  mode: 'history',
  routes
})

// 拦截
// 拦截
router.beforeEach((to, from, next) => {
  // 设置页面标题
  document.title = to.meta.title || '小U商城后台管理系统'

  // 如果要跳转的页面不是登录页面，就必要要登录成功之后才能访问
  if (to.path === '/login') {
    // 要跳转就是登录页面，不做拦截
    next()
  } else {
    // 要跳转不是登录页面，就必要要登录成功之后才能访问
    let userInfo = sessionStorage.getItem('user')
    if (!userInfo) {
      // 没有登录
      next('/login')
    } else {
      // 判断登录用户是否拥有对应的权限
      userInfo = JSON.parse(userInfo)
      // 首页是所有的用户都能访问
      userInfo.menus_url.push('/', '/statistics')
      if (userInfo.menus_url.includes(to.path)) { // userInfo.menus_url就是当前登录用户能够访问路由的path数组
        next()
      } else {
        // 没有权限访问就自动跳转到首页
        next('/')
      }
    }
  }
})

export default router
