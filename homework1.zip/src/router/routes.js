const routes = [
  {
    path: '/',
    // 重定向
    redirect: '/statistics',
    component: () => import('@/pages/main/Index'),
    children: [
      {
        path: 'statistics',
        component: () => import('@/pages/statistics/Index'),
        meta: {
          title: '主页面'
        }
      },
      {
        path: 'menu',
        component: () => import('@/pages/menu/Index'),
        meta: {
          title: '菜单管理'
        }
      },
      {
        path: 'role',
        component: () => import('@/pages/role/Index'),
        meta: {
          title: '角色管理'
        }
      },
      {
        path: 'user',
        component: () => import('@/pages/user/Index'),
        meta: {
          title: '管理员管理'
        }
      },
      {
        path: 'category',
        component: () => import('@/pages/category/Index'),
        meta: {
          title: '商品分类'
        }
      },
      {
        path: 'specs',
        component: () => import('@/pages/specs/Index'),
        meta: {
          title: '商品规格'
        }
      },
      {
        path: 'goods',
        component: () => import('@/pages/goods/Index'),
        meta: {
          title: '商品管理'
        }
      },
      {
        path: 'seckill',
        component: () => import('@/pages/seckill/Index'),
        meta: {
          title: '秒杀活动'
        }
      },
      {
        path: 'banner',
        component: () => import('@/pages/banner/Index'),
        meta: {
          title: '轮播图管理'
        }
      }
    ]
  },
  {
    path: '/login',
    component: () => import('@/pages/login/Index'),
    meta: {
      title: '登录'
    }
  }
]

export default routes
