import Vue from 'vue'
// 引入element-ui组件
import ElementUI from 'element-ui'
// 引入element-ui样式文件
import 'element-ui/lib/theme-chalk/index.css'
import './filters/img.js' // 全局过滤器 ES5引入文件
import './mixins/function.js' // 全局mixins ES5引入文件
import App from './App'
import router from './router'
// 引入vuex store
import store from './store'
// 引入reset.css
import './assets/css/reset.css'

// 使用element-ui (注册组件)
Vue.use(ElementUI)

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
