// 公共的函数库
export const validate = (data, rules) => {
  for (const k in data) {
    if (Reflect.has(rules, k)) {
      // 说明当前的data的属性在验证规则中存在，也就是需要验证
      const v = rules[k](data[k])
      if (v !== true) {
        return v
      }
    }
  }
  return true
}
