// 导入自己封装的axios对象
import http from './http'

// 添加商品分类
export const addCategory = (data) => {
  // 有数据上传，需要设置headers
  return http.post('/cateadd', data, {
    headers: {
      'Content-type': 'multipart/form-data'
    }
  })
}

// 修改分类
export const updateCategory = (data) => {
  // 判断data中是否包含id属性且大于0
  if (!data.get('id')) {
    return Promise.reject(new Error('缺少ID参数或id参数错误'))
  }
  return http.post('/cateedit', data)
}

// 删除分类
export const deleteCategory = (id) => {
  return http.post('/catedelete', { id })
}

// 获取分类数据
export const getCategoryList = (istree = true) => {
  // istree 是否需要返回树形结构 是-true,  否：不传
  let params = {}
  if (istree) {
    params = {
      istree: 1
    }
  }
  return http.get('/catelist', {
    params
  })
}